# Configuration file for database and app settings
DATABASE = 'database.db'
SECRET_KEY = 'your_secret_key'  # Same as in app.py, keep secure
